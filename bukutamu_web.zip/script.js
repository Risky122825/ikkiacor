
fetch('https://script.google.com/macros/s/AKfycbxqu2DMLwKCMUEVuX15Wo0C0SPGohsLRLbYP4SPKuJ5Zwjed4-RkdbZx0MRE1V1XtxKOQ/exec')
    .then(response => response.json())
    .then(data => {
        const tbody = document.querySelector('#data-table tbody');
        data.forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${row.ID}</td>
                <td>${row.NAMA}</td>
                <td>${row.INSTANSI}</td>
                <td>${row.KEPERLUAN}</td>
                <td>${row.WAKTU}</td>
            `;
            tbody.appendChild(tr);
        });
    })
    .catch(error => {
        console.error('Gagal mengambil data:', error);
    });
